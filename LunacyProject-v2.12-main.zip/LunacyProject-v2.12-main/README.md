# LunacyProject-v2.12

# ⚠️ USE AT YOUR OWN RISK
Lunacy Project - is a free cheat for fivem and cool it's undetected by fiveguard etc.

# ➡️ Showcase
![image](https://user-images.githubusercontent.com/127592836/225115347-b2a19695-61d7-4d42-bbd4-c8e72109a8b9.png)


## <a id="features"></a>⚙️ 〢 Features



**Aimbot**
```sh-session
- Silent
- Unsilent
- Smooth
- Assist
- Triggerbot
- FOV
- Fire delay
```

**ESP**
```sh-session
- Wallhack
- Boxes
- HP Bars
- RGB
```

**Others**
```sh-session
- Spoofer
- Dumper
- Drop weapons
```

---

## <a id="download"></a>📁 〢 Download compiled version [here](https://discord.gg/KWW7p7JAfM)

If you find any bugs, please let me know.
My discord DeviL#8097
