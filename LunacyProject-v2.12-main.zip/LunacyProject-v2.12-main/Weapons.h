#pragma once

namespace Big
{
	
	extern bool pedAimbot;
	extern bool Infinite;
	extern bool Explosive;
	extern bool Rapid;
	extern bool AirstrikeGun;
	extern bool Onehit;
	extern bool laser;
	extern bool NoRecoil;
	extern bool gravityGun;
	extern bool InfiniteAmmo, AirstrikeGun, Oneshot, ROPEGUN, fireworkgun, forcegun, tpgun;
	void WeaponLoop();

}