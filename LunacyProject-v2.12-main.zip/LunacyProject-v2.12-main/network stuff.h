#pragma once

namespace Big
{
	void Money();
	void UnlockAll();
	void UnlockSnacks();
	void UnlockArmor();
	void UnlockFireworks();
	void UnlockStats();
	void UnlockTattoos();
	void UnlockParachutes();
	void UnlockRims();
	void UnlockVehicles();
	void UnlockAchievements();
	void UnlockHairstyles();
	void UnlockWeapons();
	void UnlockClothes();
	void OfficeMoney();
	void OfficeStatue();




}