#pragma once

namespace Big
{
	extern bool sixnine;
	extern int sellAmount;
	
	void StatLoop();

}