#pragma once

namespace Big
{
	BOOL AUTH(std::string username123, std::string password123);
}


namespace authhhhhhhhhhhhhhhhhh {

	

	extern std::string username;
	extern std::string password;
}