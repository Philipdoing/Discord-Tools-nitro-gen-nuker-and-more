# LinkGen Account Generator
An Open Source Account Generator Bot!

# Features:
/generate \
/help \
/stock (automatic)

# How it works:
Put your Discord Bot Token in config.json \
Create a Free Gen role and a Premium Gen role \
Create a Generate Channel \
Make sure you have Python 3.9 installed 

You can add accounts in the /accounts folder, for help add me on Discord!

Discord: Snikker#1337
