<div id="top"></div>
<p align="center">
  <img src="https://img.shields.io/github/contributors/dropout1337/Discord-Mass-DM.svg?style=for-the-badge"/>
  <img src="https://img.shields.io/github/forks/dropout1337/Discord-Mass-DM.svg?style=for-the-badge"/>
  <img src="https://img.shields.io/github/stars/dropout1337/Discord-Mass-DM.svg?style=for-the-badge"/>
  <img src="https://img.shields.io/github/issues/dropout1337/Discord-Mass-DM.svg?style=for-the-badge"/>
  <img src="https://img.shields.io/github/license/dropout1337/Discord-Mass-DM.svg?style=for-the-badge"/>
</p>
  
---------------------------------------
  
<br/>
<div align="center">
  <a href="https://github.com/dropout1337/Discord-Mass-DM">
    <img src="https://i.imgur.com/9l4pHEN.png" alt="Logo" width="120" height="120">
  </a>
  
  <h2 align="center">Discord Mass DM </h3>

  <p align="center">
    Scrapes users from a discord server to promote/mass dm
    <br />
    <br />
    <a href="https://github.com/dropout1337/Discord-Mass-DM/issues">Report Bug</a>
    ·
    <a href="https://github.com/dropout1337/Discord-Mass-DM/issues">Request Feature</a>
  </p>
</div>
---------------------------------------

### How to use

* Download Python
* Open cmd in file path and do 'pip install -r requirements.txt'
* Run 'python3 main.py'

---------------------------------------

### Features
* Asynchronous
* Easy to use
* Free
* Auto scrapes
* Multiline message support

---------------------------------------

### Contact
View my contact information on my [website](https://kekwltd.ru)
---------------------------------------
discorddiscord-botdiscord-pydmspammermassdiscord-spammer-botdiscord-spammerdiscord-massdmdiscord-mass-dmdiscord-mass-message
discorddiscord-botdiscord-pydmspammermassdiscord-spammer-botdiscord-spammerdiscord-massdmdiscord-mass-dmdiscord-mass-message
discorddiscord-botdiscord-pydmspammermassdiscord-spammer-botdiscord-spammerdiscord-massdmdiscord-mass-dmdiscord-mass-message
discorddiscord-botdiscord-pydmspammermassdiscord-spammer-botdiscord-spammerdiscord-massdmdiscord-mass-dmdiscord-mass-message
discorddiscord-botdiscord-pydmspammermassdiscord-spammer-botdiscord-spammerdiscord-massdmdiscord-mass-dmdiscord-mass-message
discorddiscord-botdiscord-pydmspammermassdiscord-spammer-botdiscord-spammerdiscord-massdmdiscord-mass-dmdiscord-mass-message
discorddiscord-botdiscord-pydmspammermassdiscord-spammer-botdiscord-spammerdiscord-massdmdiscord-mass-dmdiscord-mass-message
discorddiscord-botdiscord-pydmspammermassdiscord-spammer-botdiscord-spammerdiscord-massdmdiscord-mass-dmdiscord-mass-message
